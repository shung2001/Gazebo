INHA ALATUS Pi 5 supplementary source files (2026-10-08)

These files are the ready-to-use equivalents of the sample files shown in the companion PDF walk-through.
They are an install/configuration starting point, NOT tested on your Raspberry Pi.

Directory deployment on the Raspberry Pi:
  ~/alatus/docker/Dockerfile
  ~/alatus/docker/compose.yaml
  ~/alatus/ros_ws/tools/udp_detection_bridge.py
  ~/alatus/vision/scripts/mock_sender.py
  ~/alatus/check_pi5.sh

Place files preserving this structure. To copy from a staging folder named
alatus_pi5_package located in your current directory:
  mkdir -p ~/alatus
  cp -a alatus_pi5_package/docker alatus_pi5_package/ros_ws alatus_pi5_package/vision ~/alatus/
  cp alatus_pi5_package/check_pi5.sh ~/alatus/

Then follow the PDF. Do not blindly overwrite files you already customized.
No swap partition changes are performed. Do not run a flight control loop.

Smoke-test summary (after installing Docker):
  cd ~/alatus/docker
  sudo docker compose build
  sudo docker compose up -d
  sudo docker compose exec ros bash -lc 'source /opt/ros/humble/setup.bash && echo "$ROS_DISTRO"'

Mock detection tests: see PDF, requires three terminals.
