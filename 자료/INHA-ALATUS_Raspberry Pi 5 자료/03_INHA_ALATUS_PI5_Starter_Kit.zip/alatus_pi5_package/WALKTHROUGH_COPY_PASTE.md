# INHA ALATUS — Raspberry Pi 5 초기 개발환경 구축 Walkthrough

**판본:** 2026-10-08 · **대상:** Raspberry Pi 5 + Raspberry Pi OS 64-bit + 64GB microSD  
**목표:** Python/venv → Docker/Compose → Ubuntu 22.04/ROS 2 Humble → Host↔Container UDP → ROS Topic까지 검증한다.  
**추가 단계:** AI HAT+ / Camera / 실제 YOLO 모델 / MAVROS는 장비와 소프트웨어 버전 확인 후 진행한다.  
**중요:** 사용자는 **별도 Swap 파티션을 만들지 않기로 결정**했다. 본 가이드는 파티션·Swap 설정을 변경하지 않는다.

> **작업 규칙**: 명령은 따로 표시된 경우를 제외하면 모두 Raspberry Pi OS의 터미널에 입력한다. `$` 프롬프트 기호는 복사하지 않는다. 각 단계 성공을 확인한 뒤 다음 단계로 넘어간다. 인터넷 접속과 `sudo` 권한이 필요하다. 이미 설치된 항목은 무조건 재설치하지 않는다. Docker 컨테이너의 명령은 [CONTAINER]라고 별도 표시한다.

## 0. 전체 구조와 성공 기준

```text
[Pi OS 64-bit HOST] Camera -> Hailo/HailoRT -> YOLO -> UDP metadata
                                                 |
[Docker Ubuntu 22.04 ARM64 + ROS 2 Humble] <-----+
        detection_bridge -> /alatus/target_detection
        -> tracker -> mission -> guidance -> MAVROS (later)
                                                 |
                                     Pixhawk 6C / PX4 (later)
```

- 지금 실행해 볼 대상: Host Python, Docker, ROS, Mock Detection UDP, ROS Topic.
- 지금 실행하지 않는 것: 실제 Servo/ESC·PX4 비행제어, 사용자 모델 .pt 학습, Swap 파티션 분할.
- 조건부 구현: AI HAT+/카메라 장비 장착 후 Hailo 공식 경로 및 YOLO .hef 추론.
- 이 문서의 `ROS_DOMAIN_ID=42`, UDP `5005`, JSON/String 토픽은 **통합 전 모의검증 임시값**이다.

## 1. 사전진단 — 절대 건너뛰지 말 것

**[HOST / 읽기 전용]** 아래 블록을 그대로 실행한다.

```bash
cat /etc/os-release
uname -m
dpkg --print-architecture
python3 --version
free -h
swapon --show
lsblk -f
df -h /
command -v docker || true
sudo docker info --format '{{.ServerVersion}}' || true
sudo docker compose version || true
```

**확인:** `uname -m` = `aarch64`, `dpkg --print-architecture` = `arm64`여야 한다. OS `VERSION_CODENAME`은 현재 설치된 값을 기록한다. `bookworm` 또는 `trixie`가 나올 수 있다. 지원하지 않는 OS·ARM32 출력이라면 이 문서의 Docker 경로를 그대로 진행하지 않는다. Docker가 이미 동작하고 Compose도 실행된다면 **3단계 설치를 건너뛴다**. `swapon --show`는 확인만 하고 설정을 바꾸지 않는다.

## 2. Python 및 작업 디렉터리 구축

**[HOST]** Python이 이미 있어도 아래는 누락된 필수 패키지를 보완할 수 있다.

```bash
sudo apt update
sudo apt install -y python3 python3-pip python3-venv \
  python3-numpy git curl ca-certificates
```

**[HOST]** 표준 디렉터리를 만든다.

```bash
mkdir -p ~/alatus/docker
mkdir -p ~/alatus/ros_ws/src ~/alatus/ros_ws/tools
mkdir -p ~/alatus/vision/models ~/alatus/vision/scripts ~/alatus/vision/logs
mkdir -p ~/alatus/venvs
```

**[HOST]** Vision 프로그램 전용 Python 가상환경. 외부 Python 라이브러리는 `sudo pip` 대신 이 환경에 설치한다.

```bash
python3 -m venv --system-site-packages ~/alatus/venvs/vision
source ~/alatus/venvs/vision/bin/activate
python --version
which python
deactivate
```

**확인:** `which python`이 `~/alatus/venvs/vision/bin/python`에 해당하는 경로를 가리켜야 한다. `--system-site-packages`는 추후 Pi OS가 `apt`로 제공하는 Hailo/Camera Python 모듈을 참조하기 위한 선택이다. 버전 호환성 자체를 보장하지는 않는다.

## 3. Docker Engine / Compose 준비 — 이미 동작한다면 건너뛰기

**[HOST / 재확인]** 다음 둘 다 성공한다면 설치 구간을 생략하고 4단계로 이동한다.

```bash
sudo docker info
sudo docker compose version
```

**[HOST / 미설치일 때만]** Raspberry Pi OS 64-bit(arm64)에서 Docker 공식 Debian 저장소 경로를 이용한다. 이미 `docker.io` 등이 설치되어 작동 중이면 충돌 가능성이 있으므로 **아래 명령으로 중복 저장소를 추가하지 말고 현재 설치상태를 먼저 확인**한다.

```bash
sudo apt update
sudo apt install -y ca-certificates curl
sudo install -m 0755 -d /etc/apt/keyrings
sudo curl -fsSL https://download.docker.com/linux/debian/gpg \
  -o /etc/apt/keyrings/docker.asc
sudo chmod a+r /etc/apt/keyrings/docker.asc
```

**[HOST]** Docker apt source를 작성한다.

```bash
sudo tee /etc/apt/sources.list.d/docker.sources > /dev/null <<EOF_DOCKER
Types: deb
URIs: https://download.docker.com/linux/debian
Suites: $(. /etc/os-release && echo "$VERSION_CODENAME")
Components: stable
Architectures: $(dpkg --print-architecture)
Signed-By: /etc/apt/keyrings/docker.asc
EOF_DOCKER
sudo apt update
```

**[HOST]** 패키지를 설치한다.

```bash
sudo apt install -y docker-ce docker-ce-cli containerd.io \
  docker-buildx-plugin docker-compose-plugin
sudo systemctl enable --now docker
sudo docker run --rm hello-world
sudo docker compose version
```

**확인:** `Hello from Docker!`라는 문구가 표시되고 Compose 버전이 출력되어야 한다. Docker 그룹 추가는 필수가 아니며 보안상 기본 지침에서는 `sudo docker`를 사용한다.

## 4. ARM64 ROS 2 Humble 이미지 다운로드

**[HOST]** Ubuntu를 별도로 설치할 필요 없다. 공식 ROS 이미지가 Ubuntu 22.04 Jammy를 기반으로 한다.

```bash
sudo docker pull --platform linux/arm64 ros:humble-ros-base-jammy
sudo docker image inspect ros:humble-ros-base-jammy \
  --format '{{.Architecture}} / {{.Os}}'
```

**확인:** `arm64 / linux`를 기대한다. 이미지 내부 확인:

```bash
sudo docker run --rm --platform linux/arm64 \
  --entrypoint bash ros:humble-ros-base-jammy \
  -lc 'cat /etc/os-release; source /opt/ros/humble/setup.bash; echo "$ROS_DISTRO"'
```

**확인:** Ubuntu 22.04 (`jammy`)와 `humble` 출력.

## 5. ALATUS 전용 Dockerfile/Compose 작성

**[HOST]** 아래 코드를 붙여넣으면 파일이 생성된다. 기존에 같은 이름의 파일을 이미 수정했다면 덮어쓰지 말고 먼저 백업한다. 압축 스타터킷에 동일한 파일이 포함되어 있다.

```bash
cat > ~/alatus/docker/Dockerfile <<'EOF_DOCKERFILE'
# ALATUS: ARM64 ROS 2 Humble / Ubuntu 22.04
FROM ros:humble-ros-base-jammy
ENV DEBIAN_FRONTEND=noninteractive \
    PYTHONDONTWRITEBYTECODE=1
RUN apt-get update && apt-get install -y --no-install-recommends \
    python3-pip python3-venv python3-numpy python3-yaml \
    python3-colcon-common-extensions \
    ros-humble-rclpy ros-humble-std-msgs \
    git iproute2 \
    && rm -rf /var/lib/apt/lists/*
WORKDIR /workspace/alatus_ws
CMD ["sleep", "infinity"]
EOF_DOCKERFILE
```

**[HOST]** Compose 파일. `network_mode: host`는 **이 Raspberry Pi 내부 localhost UDP 테스트용**이다. 기본 격리가 줄어드므로 신뢰할 수 있는 개발환경에서만 사용한다.

```bash
cat > ~/alatus/docker/compose.yaml <<'EOF_COMPOSE'
services:
  ros:
    build:
      context: .
      dockerfile: Dockerfile
    image: alatus-ros:humble
    container_name: alatus-ros
    network_mode: host
    environment:
      ROS_DOMAIN_ID: "42"
      ROS_LOCALHOST_ONLY: "1"
      PYTHONDONTWRITEBYTECODE: "1"
    volumes:
      - ../ros_ws:/workspace/alatus_ws
    working_dir: /workspace/alatus_ws
    stdin_open: true
    tty: true
    init: true
    command: ["sleep", "infinity"]
    restart: "no"
EOF_COMPOSE
```

**[HOST]** Docker 이미지 빌드 및 컨테이너 기동:

```bash
cd ~/alatus/docker
sudo docker compose build
sudo docker compose up -d
sudo docker compose ps
```

**[HOST]** Ubuntu와 ROS 2 확인:

```bash
sudo docker compose exec ros bash -lc \
  'cat /etc/os-release; source /opt/ros/humble/setup.bash; echo "$ROS_DISTRO"; python3 --version; colcon --help'
```

**확인:** Ubuntu 22.04, `humble`, Python 3.10 계열이 기대된다. `colcon --help`가 환경에 따라 실패할 경우, `colcon --help`로 명령 존재 여부를 확인한다. 아직 MAVROS를 설치하지 않았다.

## 6. ROS 2 토픽 기본 통신

**터미널 A [HOST에서 실행, Docker 안에서 ROS Publisher 실행]**

```bash
cd ~/alatus/docker
sudo docker compose exec ros bash -lc \
  'source /opt/ros/humble/setup.bash; ros2 topic pub /alatus/test std_msgs/msg/String "{data: ALATUS_OK}" -r 1'
```

**터미널 B [HOST에서 실행, Docker 안에서 ROS Subscriber 실행]**

```bash
cd ~/alatus/docker
sudo docker compose exec ros bash -lc \
  'source /opt/ros/humble/setup.bash; ros2 topic echo /alatus/test'
```

**확인:** B에서 `data: ALATUS_OK` 메시지가 반복 출력된다. 종료는 각각 `Ctrl+C`.

## 7. Host Python -> Docker UDP -> ROS 2 Topic 검증

이 단계에서는 카메라나 Hailo가 **없어도** 된다. `bbox`, `confidence`는 예시값이며, 실제 과녁 탐지값이나 Guidance가 아니다. 전달 경로 시험을 위해 임시로 `std_msgs/String`에 JSON을 넣는다. 실제 시스템에서 `alatus_msgs`로 교체한다.

**[HOST]** Bridge 코드를 생성한다. 아래 스크립트는 ROS 컨테이너 안에서만 실행한다.

```bash
cat > ~/alatus/ros_ws/tools/udp_detection_bridge.py <<'EOF_BRIDGE'
#!/usr/bin/env python3
import json
import socket
import rclpy
from rclpy.node import Node
from std_msgs.msg import String

def main():
    rclpy.init()
    node = Node('alatus_udp_detection_bridge')
    publisher = node.create_publisher(String, '/alatus/target_detection', 10)
    receiver = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    receiver.bind(('127.0.0.1', 5005))
    receiver.settimeout(0.2)
    node.get_logger().info('Listening: 127.0.0.1:5005')
    try:
        while rclpy.ok():
            try:
                raw, _ = receiver.recvfrom(4096)
            except socket.timeout:
                rclpy.spin_once(node, timeout_sec=0.0)
                continue
            try:
                payload = json.loads(raw.decode('utf-8'))
                if not isinstance(payload, dict):
                    raise ValueError('JSON object required')
            except (UnicodeDecodeError, ValueError) as exc:
                node.get_logger().warning(f'Dropped invalid packet: {exc}')
                continue
            msg = String()
            msg.data = json.dumps(payload, ensure_ascii=False)
            publisher.publish(msg)
            rclpy.spin_once(node, timeout_sec=0.0)
    except KeyboardInterrupt:
        pass
    finally:
        receiver.close()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
EOF_BRIDGE
```

**[HOST]** Mock Sender 코드를 생성한다. Host Python으로 5회만 전송한다.

```bash
cat > ~/alatus/vision/scripts/mock_sender.py <<'EOF_SENDER'
#!/usr/bin/env python3
import json
import socket
import time

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
try:
    for i in range(5):
        data = {
            'detected': True,
            'class_name': 'archery_target',
            'confidence': 0.95,
            'center_x': 320,
            'center_y': 240,
            'bbox_xyxy': [280, 200, 360, 280],
            'frame_width': 640,
            'frame_height': 480,
            'timestamp_ns': time.time_ns(),
            'source': 'mock_not_real_yolo',
            'sample_index': i
        }
        sock.sendto(json.dumps(data).encode(), ('127.0.0.1', 5005))
        print('Sent mock detection', i + 1)
        time.sleep(0.5)
finally:
    sock.close()
EOF_SENDER
```

**터미널 A [HOST에서 Docker Bridge 시작]**

```bash
cd ~/alatus/docker
sudo docker compose exec ros bash -lc \
  'source /opt/ros/humble/setup.bash; python3 /workspace/alatus_ws/tools/udp_detection_bridge.py'
```

**터미널 B [HOST에서 ROS Topic 감시]**

```bash
cd ~/alatus/docker
sudo docker compose exec ros bash -lc \
  'source /opt/ros/humble/setup.bash; ros2 topic echo /alatus/target_detection'
```

**터미널 C [Host Python 송신]**

```bash
python3 ~/alatus/vision/scripts/mock_sender.py
```

**확인:** A는 `Listening...`, C는 5회 송신 로그, B는 `archery_target` JSON이 포함된 `data` 메시지를 표시한다. 이것은 **ROS로 이어지는 데이터 경로만 성공**한 것이며 YOLO 추론/Tracking/Guidance/실비행 검증이 아니다. A/B 종료는 `Ctrl+C`. `5005` 포트가 사용 중이면 다른 포트를 양쪽 코드에 동일하게 적용한다.

## 8. [조건부] AI HAT+와 카메라

**하드웨어 모델과 OS를 확인한 뒤에만 실행.** 2026-10-08 확인한 Raspberry Pi AI 공식 문서의 기준은 Raspberry Pi OS **Trixie 64-bit**이다. Bookworm이라면 버전 적합성을 먼저 검토한다. HAT 장착은 전원 분리 후 공식 하드웨어 지침에 따른다.

**[HOST / 확인]**

```bash
cat /etc/os-release
apt-cache policy hailo-all hailo-h10-all
command -v rpicam-hello || true
```

일반 **AI HAT+ (Hailo-8 / 8L)**일 때만:

```bash
sudo apt update
sudo apt install -y dkms hailo-all
sudo reboot
```

별도 **AI HAT+ 2 (Hailo-10H)**라면, 위 `hailo-all` 대신 다음을 설치한다. **둘을 함께 설치하지 않는다.**

```bash
sudo apt update
sudo apt install -y dkms hailo-h10-all
sudo reboot
```

재부팅 후:

```bash
hailortcli fw-control identify
rpicam-hello --list-cameras
```

카메라 명령이 없다면 공식 `rpicam-apps` 또는 OS Lite용 패키지 상태를 확인한다. 카메라가 설치되어 있을 때만 다음을 테스트한다.

```bash
rpicam-hello -n -t 3000
```

추론 데모 설정파일이 존재하는지도 먼저 확인한다.

```bash
ls -l /usr/share/rpi-camera-assets/hailo_yolov8_inference.json
```

해당 파일이 존재하고 지원하는 Hailo 런타임/카메라일 때:

```bash
rpicam-hello -n -t 10000 \
  --post-process-file /usr/share/rpi-camera-assets/hailo_yolov8_inference.json
```

실행 성공 시 **사전학습 모델의 카메라-Hailo 추론 파이프라인**을 확인한 것이지 ALATUS 전용 과녁 검출 모델이 검증된 것은 아니다.

## 9. [추후] 학습된 YOLO 모델 업로드와 Hailo 변환

```text
Desktop GPU: Archery Target Dataset -> YOLO Training -> best.pt
           -> compatible ONNX export -> Hailo compiler/quantization
           -> target-specific .hef + metadata + postprocessing
Raspberry Pi OS: Camera -> HailoRT + .hef -> detector -> UDP/ROS
```

- `.pt`를 SD카드에 복사하기만 해서는 AI HAT+ 가속 추론이 되지 않는다.
- `.hef` 컴파일은 NPU 제품(8/8L/10H)과 호환 Toolchain/HailoRT 버전에 의존한다.
- 클래스 순서, 입력 크기, 정규화, NMS/후처리, 신뢰도 기준, Calibration 데이터까지 기록한다.
- 현재 프로젝트의 표적은 **그물 뒤 양궁 과녁**이다. 가림/거리/광량 변화가 포함된 실제 데이터로 정확도 검증.
- `~/alatus/vision/models` 등에 `.hef`, `labels.json`, 모델 버전/설정 메타데이터를 저장하는 구조를 권장하되 파일명은 현재 제안이다.
- 초기에 Pi 5에 PyTorch/Ultralytics 전부 설치할 필요는 없다. 표준 경로는 Pi OS HailoRT 추론이다.

## 10. [추후] MAVROS / Pixhawk 6C Bench

- ROS topic과 실제 Detection 파이프라인을 먼저 검증한 후, Dockerfile에 `ros-humble-mavros`를 **추가**하여 이미지 재빌드한다.
- MAVROS에는 GeographicLib dataset이 필요하다. Docker 컨테이너 실행 중 수동 설치만 하면 이미지를 다시 만들 때 사라지므로 **재현가능한 Dockerfile 단계**로 고정한다.
- Pixhawk 포트(TELEM 번호), UART 장치명, Baud Rate, PX4 설정, ENU↔NED, Time Sync는 아직 **TBD**.
- Telemetry/RC는 Pixhawk에 직접 연결하고 Pi의 장애로 수동개입이 막혀서는 안 된다.
- 이 매뉴얼은 안전을 위해 실제 PX4 제어·Arming·Guidance 실험 명령을 제공하지 않는다.

## 11. 실패 시 진단표

- **`docker: command not found`** → 3단계 미설치 경로 검토. 이미 다른 패키지 관리자로 설치되었는지 확인.
- **`Cannot connect to Docker daemon`** → `sudo systemctl status docker` / `sudo docker info`; 서비스 상태와 권한 확인.
- **Docker `apt` 저장소 오류** → `cat /etc/os-release`, `dpkg --print-architecture`, `/etc/apt/sources.list.d/docker.sources` 확인; 지원하지 않는 OS에서 강행하지 않음.
- **`exec format error`** → 이미지 Architecture `arm64` 확인.
- **`colcon` 누락 / Docker build 실패** → `sudo docker compose build --progress plain`; 실패한 패키지명과 apt 로그 확인. 파악 전 추가로 패키지 변경 금지.
- **ROS 토픽이 안 보임** → 같은 컨테이너에 각각 진입했는지, 두 터미널에서 동일한 ROS_DOMAIN_ID인지, `source /opt/ros/humble/setup.bash`를 실행했는지 확인.
- **UDP가 도착하지 않음** → Bridge 시작 후 Sender 실행, `network_mode: host`, UDP 5005, 동일한 localhost 및 컨테이너 기동 여부 확인.
- **`Address already in use`** → 다른 Bridge 프로세스 또는 5005 포트 충돌. 테스트 종료/포트 일치 변경.
- **Hailo 인식 실패** → HAT 종류/장착, OS Trixie 여부, 드라이버 및 Runtime 조합/`hailortcli`/`dmesg | grep -i hailo` 확인. 무작정 버전을 섞지 않는다.
- **Python `externally-managed-environment`** → Pi OS Host에서는 venv 사용; `sudo pip`나 `--break-system-packages`로 우회하지 않는다.
- **기존 Swap 서비스 오류** → 이 매뉴얼에서는 Swap을 수정하지 않으므로 무시하고 메모리 상태만 기록한다. 파티션 작업은 수행하지 않는다.

## 12. 성공 체크포인트 / 운영 명령

- [ ] OS=`Raspberry Pi OS 64-bit`, ARM64 확인
- [ ] Python venv 활성화 성공
- [ ] Docker `hello-world` 성공
- [ ] ROS ARM64 이미지와 `humble` 확인
- [ ] `docker compose build/up/ps` 성공
- [ ] ROS `/alatus/test` Topic pub/echo 성공
- [ ] Host Mock Sender → UDP Bridge → `/alatus/target_detection` 확인
- [ ] (조건부) Hailo/Camera/사전학습 추론 성공
- [ ] (조건부) 실제 과녁 모델 및 Pixhawk Bench 통합 검증

컨테이너 종료:

```bash
cd ~/alatus/docker
sudo docker compose down
```

재시작:

```bash
cd ~/alatus/docker
sudo docker compose up -d
sudo docker compose ps
```

**주의:** 컨테이너 삭제/재빌드 시 컨테이너 내부에만 설치·저장한 데이터는 보존되지 않을 수 있다. Workspace는 Host의 `~/alatus/ros_ws` bind mount에 저장한다. 향후 colcon build 결과의 파일 소유권 문제를 방지하려면 팀용 비root 컨테이너 설정을 도입한다.

## 13. 공식 문서 및 검증 범위

확인 기준일 **2026-10-08**. 아래는 공개 문서에 기반한 설치 경로이며, 특정 사용자의 Raspberry Pi에서 실제 실행 성공을 주장하지 않는다.

1. Docker Engine Debian(64-bit ARM64): https://docs.docker.com/engine/install/debian/
2. Docker Raspberry Pi OS 페이지는 **32-bit/armhf 전용**: https://docs.docker.com/engine/install/raspberry-pi-os/
3. 공식 ROS Docker 이미지 태그/arm64v8: https://github.com/docker-library/official-images/blob/master/library/ros
4. Raspberry Pi Hailo AI 공식 설치(모델별 패키지, Trixie): https://www.raspberrypi.com/documentation/computers/ai.html
5. Raspberry Pi 카메라 명령: https://www.raspberrypi.com/documentation/computers/camera_software.html
6. Raspberry Pi OS Python/venv: https://www.raspberrypi.com/documentation/computers/os.html
7. MAVROS ROS 2 및 GeographicLib: https://github.com/mavlink/mavros/blob/ros2/docs/installation.md

**버전 Freeze 전의 미확정 항목:** Pi OS 현재 판본, Pi RAM, AI HAT+ 실제 제품명, Camera, HailoRT/컴파일러, 모델 스펙, ROS 메시지 상세, 최종 통신/좌표계/Time Sync/PX4 포트 설정.
