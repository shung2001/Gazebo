#!/usr/bin/env python3
"""ALATUS bench-test only. No camera, model, or flight commands."""
import json
import socket
import time

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
try:
    for sample_index in range(5):
        payload = {
            "detected": True,
            "class_name": "archery_target",
            "confidence": 0.95,
            "center_x": 320,
            "center_y": 240,
            "bbox_xyxy": [280, 200, 360, 280],
            "frame_width": 640,
            "frame_height": 480,
            "timestamp_ns": time.time_ns(),
            "sample_index": sample_index,
            "source": "mock_not_real_yolo",
        }
        data = json.dumps(payload).encode("utf-8")
        sock.sendto(data, ("127.0.0.1", 5005))
        print(f"Sent mock detection {sample_index + 1}/5")
        time.sleep(0.5)
finally:
    sock.close()
