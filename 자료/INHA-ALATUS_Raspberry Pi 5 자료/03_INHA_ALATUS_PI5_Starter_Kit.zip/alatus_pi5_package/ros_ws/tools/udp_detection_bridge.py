#!/usr/bin/env python3
"""ALATUS bench-test only: localhost UDP JSON -> ROS 2 std_msgs/String.

Not a production flight or typed ROS message interface.
"""
import json
import socket

import rclpy
from rclpy.node import Node
from std_msgs.msg import String


def main():
    rclpy.init()
    node = Node("alatus_udp_detection_bridge")
    publisher = node.create_publisher(String, "/alatus/target_detection", 10)
    receiver = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    receiver.bind(("127.0.0.1", 5005))
    receiver.settimeout(0.2)
    node.get_logger().info("Mock detection bridge listening on 127.0.0.1:5005")
    try:
        while rclpy.ok():
            try:
                raw, _ = receiver.recvfrom(4096)
            except socket.timeout:
                rclpy.spin_once(node, timeout_sec=0.0)
                continue
            try:
                payload = json.loads(raw.decode("utf-8"))
                if not isinstance(payload, dict):
                    raise ValueError("JSON object required")
            except (UnicodeDecodeError, ValueError) as exc:
                node.get_logger().warning(f"Dropping invalid detection: {exc}")
                continue
            message = String()
            message.data = json.dumps(payload, ensure_ascii=False)
            publisher.publish(message)
            rclpy.spin_once(node, timeout_sec=0.0)
    except KeyboardInterrupt:
        pass
    finally:
        receiver.close()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
