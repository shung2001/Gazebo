#!/usr/bin/env bash
# Read-only diagnostics. No install, reboot, disk partition, or swap change.
set -u
printf '\n== OS ==\n'
cat /etc/os-release
printf '\n== Architecture ==\n'
uname -m
dpkg --print-architecture
printf '\n== Python ==\n'
python3 --version || true
printf '\n== RAM / swap ==\n'
free -h
swapon --show || true
printf '\n== Root filesystem ==\n'
df -h /
printf '\n== Docker CLI / Compose ==\n'
command -v docker && docker --version || true
if command -v docker >/dev/null 2>&1; then
    sudo docker compose version || true
    sudo docker info --format '{{.ServerVersion}}' || true
fi
printf '\n== Hailo packages (may be unavailable before installing hardware) ==\n'
apt-cache policy hailo-all hailo-h10-all 2>/dev/null || true
