import time
import unittest
from alatus_core.logic import mission_decision, guidance_decision, valid_detection
from alatus_core.protocol import make_detection, parse_detection

class DecisionTests(unittest.TestCase):
    def setUp(self):
        self.now = 1800000000.0  # fixed clock -> deterministic
    def check(self, case, expected_state, expected_dir):
        d = make_detection(self.now, 2, case)
        self.assertTrue(valid_detection(d))
        self.assertEqual(mission_decision(d,self.now), expected_state)
        self.assertEqual(guidance_decision(d,expected_state,self.now), expected_dir)
        self.assertEqual(parse_detection(__import__('json').dumps(d)), d)
    def test_left(self): self.check('left','TARGET_DETECTED','LEFT')
    def test_right(self): self.check('right','TARGET_DETECTED','RIGHT')
    def test_center(self): self.check('center','TARGET_DETECTED','ON_TARGET')
    def test_missing(self): self.check('missing','TARGET_LOST','HOLD')
    def test_low_conf(self): self.check('low_conf','TARGET_LOST','HOLD')
    def test_stale(self): self.check('stale','TARGET_LOST','HOLD')
    def test_waiting(self):
        self.assertEqual(mission_decision(None,self.now),'WAITING')
        self.assertEqual(guidance_decision(None,'WAITING',self.now),'HOLD')
    def test_future_timestamp(self):
        d=make_detection(self.now,1,'left');d['timestamp']=self.now+30
        self.assertEqual(mission_decision(d,self.now),'TARGET_LOST')
    def test_invalid_json(self):
        with self.assertRaises(ValueError): parse_detection('{"schema":"other"}')
    def test_invalid_array_json(self):
        with self.assertRaises(ValueError): parse_detection("[1,2,3]")
    def test_wrong_class(self):
        d=make_detection(self.now,1,'left');d['class_name']='recovery_net'
        self.assertFalse(valid_detection(d))
    def test_deadband_boundary(self):
        d=make_detection(self.now,1,'center');d['center_x']=320
        self.assertEqual(guidance_decision(d,'TARGET_DETECTED',self.now),'ON_TARGET')

if __name__ == '__main__': unittest.main()
