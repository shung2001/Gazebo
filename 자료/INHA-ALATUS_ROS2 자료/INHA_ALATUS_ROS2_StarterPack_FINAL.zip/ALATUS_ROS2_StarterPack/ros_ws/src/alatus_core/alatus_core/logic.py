"""Pure Python educational decision logic. No ROS/PX4/MAVLink imports."""
import math

ALLOWED_STATES = {'WAITING', 'TARGET_DETECTED', 'TARGET_LOST', 'ABORT'}

def valid_detection(d):
    if not isinstance(d, dict):
        return False
    try:
        if not isinstance(d.get('detected'), bool):
            return False
        if d.get('class_name') != 'archery_target':
            return False
        if not isinstance(d.get('source'), str) or not d['source']:
            return False
        if not isinstance(d.get('seq'), int) or isinstance(d['seq'], bool) or d['seq'] < 0:
            return False
        w, h = d.get('frame_width'), d.get('frame_height')
        if not all(isinstance(x, int) and not isinstance(x,bool) and x > 0 for x in (w, h)):
            return False
        for k in ('confidence', 'center_x', 'center_y', 'timestamp'):
            v = d.get(k)
            if not isinstance(v, (int,float)) or isinstance(v,bool) or not math.isfinite(v):
                return False
        if not (0 <= d['confidence'] <= 1 and 0 <= d['center_x'] <= w and 0 <= d['center_y'] <= h):
            return False
        b = d.get('bbox')
        if not isinstance(b, list) or len(b) != 4:
            return False
        if not all(isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x) for x in b):
            return False
        x, y, bw, bh = b
        if min(x, y, bw, bh) < 0 or bw > w or bh > h or x+bw > w or y+bh > h:
            return False
        return True
    except (TypeError, ValueError, KeyError):
        return False

def detection_fresh(d, now, timeout_s=1.5, future_tolerance_s=0.5):
    if not valid_detection(d):
        return False
    age = float(now) - float(d['timestamp'])
    return -future_tolerance_s <= age <= timeout_s

def mission_decision(d, now, threshold=0.6, timeout_s=1.5):
    if d is None:
        return 'WAITING'
    if (detection_fresh(d, now, timeout_s) and
        d['detected'] and d['confidence'] >= threshold):
        return 'TARGET_DETECTED'
    return 'TARGET_LOST'

def guidance_decision(d, state, now, threshold=0.6, timeout_s=1.5, deadband_ratio=0.08):
    """Only LEFT/RIGHT/ON_TARGET/HOLD labels. Not aircraft control."""
    if state != 'TARGET_DETECTED':
        return 'HOLD'
    if mission_decision(d, now, threshold, timeout_s) != 'TARGET_DETECTED':
        return 'HOLD'
    if not (0 <= deadband_ratio <= 0.5):
        return 'HOLD'
    error = (d['center_x'] / d['frame_width']) - 0.5
    if error < -deadband_ratio:
        return 'LEFT'
    if error > deadband_ratio:
        return 'RIGHT'
    return 'ON_TARGET'
