"""Offline regression: no ROS installation needed."""
import time
from .protocol import make_detection
from .logic import mission_decision, guidance_decision

def main():
    now = time.time()
    for name, state, direction in [
        ('left','TARGET_DETECTED','LEFT'),
        ('right','TARGET_DETECTED','RIGHT'),
        ('center','TARGET_DETECTED','ON_TARGET'),
        ('missing','TARGET_LOST','HOLD'),
        ('low_conf','TARGET_LOST','HOLD'),
        ('stale','TARGET_LOST','HOLD'),
    ]:
        d = make_detection(now, 0, name)
        result_state = mission_decision(d, now)
        result_dir = guidance_decision(d, result_state, now)
        assert (result_state, result_dir) == (state, direction), (name, result_state, result_dir)
        print(f'{name:9s} => {result_state:16s} / {result_dir}')
    print('PASS: six deterministic logical scenarios (not a ROS or hardware test)')

if __name__ == '__main__':
    main()
