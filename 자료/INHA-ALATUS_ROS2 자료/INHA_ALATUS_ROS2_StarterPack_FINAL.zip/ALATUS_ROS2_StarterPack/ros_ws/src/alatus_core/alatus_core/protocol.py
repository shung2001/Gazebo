"""v0 educational String/JSON payload contract, NOT frozen ALATUS interface."""
import json
from .logic import valid_detection

SCHEMA = 'alatus.demo.detection.v0'

def make_detection(now, seq, kind='center', width=640, height=480):
    x_ratios = {'left': 0.2, 'right': 0.8, 'center': 0.5,
                'missing': 0.5, 'low_conf': 0.5, 'stale': 0.5}
    if kind not in x_ratios:
        raise ValueError('unknown scenario: ' + kind)
    cx = round(width * x_ratios[kind], 2)
    cy = round(height * 0.5, 2)
    boxw, boxh = 64.0, 64.0
    stamp = float(now) - (20.0 if kind == 'stale' else 0.0)
    return {
        'schema': SCHEMA, 'detected': kind != 'missing',
        'class_name': 'archery_target',
        'confidence': 0.2 if kind == 'low_conf' else (0.0 if kind == 'missing' else 0.95),
        'center_x': cx, 'center_y': cy,
        'bbox': [cx-boxw/2, cy-boxh/2, boxw, boxh],  # pixel xywh, top-left origin
        'frame_width': width, 'frame_height': height,
        'timestamp': stamp,  # UNIX epoch, UTC seconds; demonstrator wall clock
        'source': 'mock', 'seq': int(seq)
    }

def parse_detection(raw):
    obj = json.loads(raw)
    if not isinstance(obj, dict) or obj.get('schema') != SCHEMA or not valid_detection(obj):
        raise ValueError('unexpected schema or invalid detection')
    return obj
