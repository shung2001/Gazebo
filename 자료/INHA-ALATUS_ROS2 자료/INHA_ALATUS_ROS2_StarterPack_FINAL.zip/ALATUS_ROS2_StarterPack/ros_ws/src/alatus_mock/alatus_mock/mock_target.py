import json
import time
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from alatus_core.protocol import make_detection

class MockTarget(Node):
    def __init__(self):
        super().__init__('mock_target')
        self.declare_parameter('scenario', 'cycle')
        self.declare_parameter('period_s', 0.5)
        self.pub = self.create_publisher(String, '/alatus/target_detection', 10)
        self.seq = 0
        self.cases = ['left','center','right','missing','low_conf','stale']
        self.timer = self.create_timer(float(self.get_parameter('period_s').value), self.publish_one)

    def publish_one(self):
        mode = str(self.get_parameter('scenario').value)
        kind = self.cases[(self.seq // 4) % len(self.cases)] if mode == 'cycle' else mode
        try:
            data = make_detection(time.time(), self.seq, kind)
        except ValueError as exc:
            self.get_logger().error(str(exc))
            return
        m = String()
        m.data = json.dumps(data, separators=(',', ':'))
        self.pub.publish(m)
        self.get_logger().info(f'mock seq={self.seq} scenario={kind}')
        self.seq += 1

def main(args=None):
    rclpy.init(args=args)
    node = MockTarget()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
