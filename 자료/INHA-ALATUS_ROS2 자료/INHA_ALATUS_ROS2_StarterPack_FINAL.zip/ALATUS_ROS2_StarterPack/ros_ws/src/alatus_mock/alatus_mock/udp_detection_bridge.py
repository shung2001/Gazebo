"""OPTIONAL: receives STRICT alatus.demo.detection.v0 UDP JSON on loopback.
Not guaranteed to accept existing Starter Kit's undocumented JSON layout.
"""
import json
import socket
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from alatus_core.protocol import parse_detection

class UDPBridge(Node):
    def __init__(self):
        super().__init__('udp_detection_bridge')
        self.declare_parameter('bind_host', '127.0.0.1')
        self.declare_parameter('bind_port', 15000)
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.setblocking(False)
        self.socket.bind((str(self.get_parameter('bind_host').value),
                          int(self.get_parameter('bind_port').value)))
        self.pub = self.create_publisher(String, '/alatus/target_detection', 10)
        self.timer = self.create_timer(0.02, self.poll)
        self.get_logger().info('STRICT demo UDP bridge (do not run with mock_target)')

    def poll(self):
        try:
            payload, _ = self.socket.recvfrom(8192)
        except BlockingIOError:
            return
        try:
            obj = parse_detection(payload.decode('utf-8'))
        except (UnicodeError, ValueError, KeyError, TypeError, json.JSONDecodeError):
            self.get_logger().warning('dropped invalid UDP packet')
            return
        msg = String()
        msg.data = json.dumps(obj, separators=(',', ':'))
        self.pub.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = UDPBridge()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.socket.close()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
