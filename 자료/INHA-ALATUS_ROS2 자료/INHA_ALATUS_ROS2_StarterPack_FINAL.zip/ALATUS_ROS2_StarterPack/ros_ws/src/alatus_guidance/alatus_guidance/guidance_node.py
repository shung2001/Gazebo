"""Educational display-only guidance labels; never transmits aircraft commands."""
import json
import time
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from alatus_core.protocol import parse_detection
from alatus_core.logic import guidance_decision, ALLOWED_STATES

class Guidance(Node):
    def __init__(self):
        super().__init__('guidance_node')
        self.declare_parameter('confidence_threshold', 0.6)
        self.declare_parameter('target_timeout_s', 1.5)
        self.declare_parameter('deadband_ratio', 0.08)
        self.declare_parameter('mission_timeout_s', 1.0)
        self.detection = None
        self.state = None
        self.state_received_at = 0.0
        self.state_seq = -1
        self.previous_label = None
        self.sub_det = self.create_subscription(String, '/alatus/target_detection', self.on_detection, 10)
        self.sub_state = self.create_subscription(String, '/alatus/mission_state', self.on_state, 10)
        self.pub = self.create_publisher(String, '/alatus/guidance_decision', 10)
        self.timer = self.create_timer(0.2, self.tick)

    def on_detection(self, msg):
        try:
            self.detection = parse_detection(msg.data)
        except (ValueError, TypeError, KeyError, json.JSONDecodeError):
            self.detection = None

    def on_state(self, msg):
        try:
            obj = json.loads(msg.data)
            if (obj['state'] not in ALLOWED_STATES or
                not isinstance(obj['seq'], int)):
                raise ValueError('invalid mission state')
            self.state = obj['state']
            self.state_seq = obj['seq']
            self.state_received_at = time.time()
        except (ValueError, TypeError, KeyError):
            self.state = None
            self.state_received_at = 0.0
            self.state_seq = -1

    def tick(self):
        now = time.time()
        fresh_state = (self.state is not None and
          now - self.state_received_at <= float(self.get_parameter('mission_timeout_s').value))
        seq_match = (self.detection is not None and self.detection['seq'] == self.state_seq)
        state = self.state if fresh_state and seq_match else None
        label = guidance_decision(self.detection, state, now,
          float(self.get_parameter('confidence_threshold').value),
          float(self.get_parameter('target_timeout_s').value),
          float(self.get_parameter('deadband_ratio').value))
        payload = {'decision':label, 'timestamp':now, 'source':'guidance_demo',
                   'flight_control_enabled': False,
                   'seq':self.detection['seq'] if self.detection else -1}
        msg = String()
        msg.data = json.dumps(payload, separators=(',', ':'))
        self.pub.publish(msg)
        if label != self.previous_label:
            self.get_logger().info(f'DISPLAY ONLY: {label}')
            self.previous_label = label

def main(args=None):
    rclpy.init(args=args)
    node = Guidance()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
