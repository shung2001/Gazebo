from setuptools import setup, find_packages
from glob import glob
import os

package_name = 'alatus_mission'

setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(exclude=['test', 'tests']),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ] + [],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='ALATUS development team',
    maintainer_email='alatus@example.invalid',
    description='Educational, non-flight ALATUS ROS 2 software',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={'console_scripts': [
            "mission_node = alatus_mission.mission_node:main"
    ]},
)
