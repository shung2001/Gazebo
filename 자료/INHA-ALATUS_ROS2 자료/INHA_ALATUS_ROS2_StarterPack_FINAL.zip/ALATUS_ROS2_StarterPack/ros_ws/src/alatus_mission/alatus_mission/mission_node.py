import json
import time
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from alatus_core.protocol import parse_detection
from alatus_core.logic import mission_decision

class Mission(Node):
    def __init__(self):
        super().__init__('mission_node')
        self.declare_parameter('confidence_threshold', 0.6)
        self.declare_parameter('target_timeout_s', 1.5)
        self.declare_parameter('abort_after_s', 0.0)  # 0 = disabled; educational flag
        self.last = None
        self.seen_any = False
        self.first_lost_at = None
        self.previous_state = None
        self.sub = self.create_subscription(String, '/alatus/target_detection', self.on_detection, 10)
        self.pub = self.create_publisher(String, '/alatus/mission_state', 10)
        self.timer = self.create_timer(0.2, self.tick)

    def on_detection(self, message):
        self.seen_any = True
        try:
            self.last = parse_detection(message.data)
        except (ValueError, TypeError, KeyError, json.JSONDecodeError) as exc:
            self.get_logger().warning(f'discard invalid detection: {exc}')
            self.last = None  # fail closed: invalid input cannot retain last good detection
            self.first_lost_at = self.first_lost_at or time.time()

    def tick(self):
        now = time.time()
        state = mission_decision(self.last, now,
            float(self.get_parameter('confidence_threshold').value),
            float(self.get_parameter('target_timeout_s').value))
        if self.seen_any and self.last is None:
            state = 'TARGET_LOST'
        if state == 'TARGET_LOST':
            if self.first_lost_at is None:
                self.first_lost_at = now
            abort_s = float(self.get_parameter('abort_after_s').value)
            if abort_s > 0 and now - self.first_lost_at >= abort_s:
                state = 'ABORT'
        elif state == 'TARGET_DETECTED':
            self.first_lost_at = None
        data = {'state':state, 'timestamp':now,
                'seq': self.last['seq'] if self.last else -1,
                'source':'mission_demo'}
        msg = String()
        msg.data = json.dumps(data, separators=(',', ':'))
        self.pub.publish(msg)
        if state != self.previous_state:
            self.get_logger().info(f'mission transition -> {state}')
            self.previous_state = state

def main(args=None):
    rclpy.init(args=args)
    node = Mission()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
