from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition, UnlessCondition
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare

def generate_launch_description():
    use_mock = LaunchConfiguration('use_mock')
    scenario = LaunchConfiguration('scenario')
    config = LaunchConfiguration('config')
    default_config = PathJoinSubstitution([
        FindPackageShare('alatus_bringup'), 'config', 'dev.yaml'])
    return LaunchDescription([
        DeclareLaunchArgument('use_mock', default_value='true'),
        DeclareLaunchArgument('scenario', default_value='cycle'),
        DeclareLaunchArgument('config', default_value=default_config),
        Node(package='alatus_mock', executable='mock_target', name='mock_target',
             parameters=[config, {'scenario': scenario}],
             condition=IfCondition(use_mock), output='screen'),
        Node(package='alatus_mock', executable='udp_detection_bridge',
             name='udp_detection_bridge', condition=UnlessCondition(use_mock),
             output='screen'),
        Node(package='alatus_mission', executable='mission_node', name='mission_node',
             parameters=[config], output='screen'),
        Node(package='alatus_guidance', executable='guidance_node', name='guidance_node',
             parameters=[config], output='screen'),
    ])
