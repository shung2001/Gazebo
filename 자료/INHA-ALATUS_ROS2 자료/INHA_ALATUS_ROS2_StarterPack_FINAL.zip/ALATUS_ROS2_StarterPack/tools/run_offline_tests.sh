#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
python3 tools/check_source.py
PYTHONPATH=ros_ws/src/alatus_core python3 -m unittest discover -s ros_ws/src/alatus_core/test -v
PYTHONPATH=ros_ws/src/alatus_core python3 -m alatus_core.verify_logic
