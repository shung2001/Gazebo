"""Static cross-file checks. NOT a ROS 2, colcon, Docker or hardware test."""
from pathlib import Path
import ast
import re
import sys
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
workspace = root / 'ros_ws' / 'src'
names = ('alatus_core', 'alatus_mock', 'alatus_mission',
         'alatus_guidance', 'alatus_bringup')
executables = {}
for name in names:
    pkg = workspace / name
    assert pkg.is_dir(), name
    xml = ET.parse(pkg / 'package.xml').getroot()
    assert xml.findtext('name') == name
    assert xml.find('export/build_type').text == 'ament_python'
    assert (pkg / 'resource' / name).exists()
    assert (pkg / name / '__init__.py').exists()
    source = (pkg / 'setup.py').read_text(encoding='utf-8')
    assert f"package_name = '{name}'" in source
    assert "'share/' + package_name" in source
    matches = re.findall(r'"([\w]+) = ([\w]+)\.([\w]+):main"', source)
    for command, module_pkg, module in matches:
        assert module_pkg == name
        assert (pkg / name / (module + '.py')).exists(), (name, command)
        executables[command] = name
    for file in pkg.rglob('*.py'):
        ast.parse(file.read_text(encoding='utf-8'), filename=str(file))

launch = (workspace/'alatus_bringup'/'launch'/'demo.launch.py').read_text()
for command in ('mock_target', 'udp_detection_bridge', 'mission_node', 'guidance_node'):
    assert command in executables
    assert f"executable='{command}'" in launch
for file in ('dev.yaml', 'onboard.yaml'):
    yaml = (workspace/'alatus_bringup'/'config'/file).read_text()
    for node in ('mock_target:', 'mission_node:', 'guidance_node:'):
        assert node in yaml and 'ros__parameters:' in yaml

for topic, min_expected in (('/alatus/target_detection', 3),
                            ('/alatus/mission_state', 2),
                            ('/alatus/guidance_decision', 1)):
    occurrences = 0
    for name in names:
        for file in (workspace / name).rglob('*.py'):
            if file.name.endswith('.launch.py'):
                continue
            occurrences += file.read_text(encoding='utf-8').count(topic)
    assert occurrences >= min_expected, (topic, occurrences)

print('PASS: 5 package manifests, entrypoints, launch executable references,')
print('      Python AST, topic strings, and parameter YAML presence (STATIC only).')
