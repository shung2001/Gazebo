"""Run on Raspberry Pi OS host (same physical Pi as host-network container)."""
import json, socket, time, argparse
# Uses no ROS libraries. Same schema as alatus_core.protocol.make_detection.

def make(now, seq, case):
    x = {'left':128.0,'center':320.0,'right':512.0,'missing':320.0}[case]
    return dict(schema='alatus.demo.detection.v0', detected=case!='missing',
                class_name='archery_target', confidence=0.0 if case=='missing' else 0.95,
                center_x=x,center_y=240.0,bbox=[x-32,208.0,64.0,64.0],
                frame_width=640,frame_height=480,timestamp=now,source='udp_mock',seq=seq)

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--scenario',choices=['left','right','center','missing'],default='left')
    p.add_argument('--port',type=int,default=15000)
    p.add_argument('--count',type=int,default=10)
    a=p.parse_args()
    with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as s:
        for seq in range(a.count):
            obj=make(time.time(),seq,a.scenario)
            s.sendto(json.dumps(obj).encode('utf-8'),('127.0.0.1',a.port))
            print('sent',a.scenario,seq)
            time.sleep(0.2)

if __name__=='__main__': main()
