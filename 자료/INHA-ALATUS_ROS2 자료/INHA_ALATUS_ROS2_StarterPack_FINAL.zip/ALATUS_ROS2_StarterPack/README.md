# INHA ALATUS ROS 2 Mission/Guidance - standalone educational starter

**Scope:** MOCK archery-target detection -> mission state -> DISPLAY-ONLY LEFT/RIGHT/ON_TARGET/HOLD.
No MAVROS, PX4, servo or actual aircraft commands. Package/topic/schema are **proposed examples**, not project-frozen.

## Quick start after ROS 2 Humble installation (WSL Ubuntu 22.04)

```bash
mkdir -p ~/alatus_ws/src
cp -a ros_ws/src/. ~/alatus_ws/src/
source /opt/ros/humble/setup.bash
cd ~/alatus_ws
rosdep install --from-paths src --ignore-src -r -y --rosdistro humble
colcon build --symlink-install
source install/setup.bash
export ROS_DOMAIN_ID=42
export ROS_LOCALHOST_ONLY=1
ros2 launch alatus_bringup demo.launch.py scenario:=cycle
```

Terminal 2: `source /opt/ros/humble/setup.bash; source ~/alatus_ws/install/setup.bash; export ROS_DOMAIN_ID=42; export ROS_LOCALHOST_ONLY=1; ros2 topic echo /alatus/guidance_decision`

## Pure logic tests (also runnable without ROS)

```bash
PYTHONPATH=ros_ws/src/alatus_core python3 -m unittest discover -s ros_ws/src/alatus_core/test -v
PYTHONPATH=ros_ws/src/alatus_core python3 -m alatus_core.verify_logic
python3 tools/check_source.py
```

## Pi migration

Read PDF 03. Source only: copy `ros_ws/src` to `~/alatus/ros_ws/src`. Docker mounts that workspace to `/workspace/alatus_ws`, then rebuild there. `docker/` here is a standalone demonstration and must not overwrite an unseen pre-existing Starter Kit. On Pi, first check `docker compose config` and `docker compose build` works with its ARM64 environment.

## Strict UDP example

Inside container use `ros2 launch alatus_bringup demo.launch.py use_mock:=false`; on Pi host run `python3 tools/send_udp_demo.py --scenario left`. This validates local UDP -> ROS String JSON -> Mission -> Guidance. The pre-existing ALATUS kit uses an unknown original schema and must be compared field-by-field before reuse. Do not run both mock_target and UDP bridge simultaneously on the same topic during a test.

## Notes

- `std_msgs/String` JSON is a bootstrap contract. A later `alatus_msgs` custom interface may replace it.
- Example timeout/confidence/deadband and `ROS_DOMAIN_ID=42` are educational, not frozen.
- `dev.yaml` and `onboard.yaml` are actual ROS parameter YAML files loaded by `demo.launch.py` via `config:=...`. `ROS_DOMAIN_ID` remains a shell/Compose environment variable, not a ROS node parameter.
- Camera, Hailo, time sync, Pixhawk, MAVROS, aerodynamic control all TBD and out of scope.

**Validation note:** current code has deterministic unit tests for mission and display labels; full ROS, Docker, and Pi tests need to be executed in target environments.
