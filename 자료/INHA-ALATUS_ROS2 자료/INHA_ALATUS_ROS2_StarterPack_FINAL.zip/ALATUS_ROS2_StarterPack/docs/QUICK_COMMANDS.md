# ALATUS ROS 2 - Commands by Machine

All packages and numeric thresholds are **learning-only examples**. Verify with PDF 01 -> 02 -> 03.

## A. WSL Ubuntu 22.04 (after installing ROS Humble according to PDF 01)

Replace `<PACK_DIR>` with the absolute path to the extracted starter pack root:

```bash
export PACK_DIR="<PACK_DIR>"
mkdir -p ~/alatus_ws/src
cp -a "$PACK_DIR/ros_ws/src/." ~/alatus_ws/src/
cp "$PACK_DIR/.gitignore" ~/alatus_ws/.gitignore
source /opt/ros/humble/setup.bash
cd ~/alatus_ws
rosdep install --from-paths src --ignore-src -r -y --rosdistro humble
colcon build --symlink-install
source install/setup.bash
export ROS_DOMAIN_ID=42
export ROS_LOCALHOST_ONLY=1
ros2 launch alatus_bringup demo.launch.py scenario:=cycle
```

In a SECOND WSL terminal:

```bash
source /opt/ros/humble/setup.bash
source ~/alatus_ws/install/setup.bash
export ROS_DOMAIN_ID=42
export ROS_LOCALHOST_ONLY=1
ros2 topic echo /alatus/guidance_decision
```

Offline tests:

```bash
cd "$PACK_DIR"
bash tools/run_offline_tests.sh
```

## B. Transfer to Raspberry Pi OS Host

Replace each placeholder and confirm SSH access first:

```bash
export PI_USER="<PI_USER>"
export PI_IP="<PI_IP>"
export PI_SSH="${PI_USER}@${PI_IP}"
ssh "$PI_SSH" 'mkdir -p ~/alatus/ros_ws/src ~/alatus/ros2_demo'
scp -r ~/alatus_ws/src/. "$PI_SSH:~/alatus/ros_ws/src/"
scp -r "$PACK_DIR/docker" "$PACK_DIR/tools" "$PI_SSH:~/alatus/ros2_demo/"
```

## C. Raspberry Pi OS Host - standalone Docker demo

```bash
cd ~/alatus/ros2_demo/docker
docker compose config
docker compose up -d --build
docker compose exec ros bash
```

## D. Docker Container Terminal (Pi, aarch64)

```bash
source /opt/ros/humble/setup.bash
cd /workspace/alatus_ws
if [ ! -f /etc/ros/rosdep/sources.list.d/20-default.list ]; then rosdep init; fi
rosdep update
rosdep install --from-paths src --ignore-src -r -y --rosdistro humble
colcon build --symlink-install
source install/setup.bash
ros2 launch alatus_bringup demo.launch.py scenario:=cycle \
  config:=/workspace/alatus_ws/src/alatus_bringup/config/onboard.yaml
```

Run a second `docker compose exec ros bash` terminal and inspect topic output. This is NOT a PX4/servo/flight-control connection.

## E. Optional local UDP bridge (Pi)

Container terminal (stop previous mock launch):

```bash
source /opt/ros/humble/setup.bash
source /workspace/alatus_ws/install/setup.bash
ros2 launch alatus_bringup demo.launch.py use_mock:=false
```

Pi Host terminal:

```bash
python3 ~/alatus/ros2_demo/tools/send_udp_demo.py --scenario left --count 20
```

**Note:** The old Starter Kit was not supplied; its bridge schema and UDP port MUST be inspected before mixing components.
