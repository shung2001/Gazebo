# INHA ALATUS ROS 2 Starter Pack - Validation Status (2026-10-08)

## Scope and labels

- **Executed locally (host without ROS):** Python syntax check, package metadata/entrypoint/launch/topic static checks, fixed-input Python unit tests, deterministic pure-function sample runner.
- **Source/documentation verified online:** Microsoft WSL, VS Code WSL, ROS 2 apt-source, ROS official Humble Docker image with arm64, Docker Compose configuration semantics.
- **Not executed:** Actual Windows WSL2 install, rosdep install, colcon build, ROS DDS publisher/subscriber, rosbag, docker compose config/build, Docker ARM64 runtime, Raspberry Pi 5 hardware, Hailo/YOLO, MAVROS/PX4, actuator functions.

The code contains NO MAVLink/PX4 interface and cannot command servo/flight controls.

## Interface proposal, NOT frozen

- Detection: `/alatus/target_detection`, `std_msgs/msg/String` encoded `alatus.demo.detection.v0` JSON
- Mission: `/alatus/mission_state`, `std_msgs/msg/String` JSON
- Display-only decision: `/alatus/guidance_decision`, `std_msgs/msg/String` JSON
- Pixel schema: xywh bbox, top-left origin, `timestamp` Unix epoch UTC seconds
- Learning-only thresholds: confidence 0.6, target timeout 1.5s, deadband width ratio 0.08
- ROS_DOMAIN_ID=42, ROS_LOCALHOST_ONLY=1 are demo environment settings

## Input/Output expectation table (unit-test logic)

| Input case | Mission | Guidance label |
|---|---|---|
| left | TARGET_DETECTED | LEFT |
| right | TARGET_DETECTED | RIGHT |
| center | TARGET_DETECTED | ON_TARGET |
| missing | TARGET_LOST | HOLD |
| low_conf | TARGET_LOST | HOLD |
| stale | TARGET_LOST | HOLD |

User must fill in actual WSL / Pi Docker Pass/Fail after executing corresponding PDF instructions. 

## Official links

- https://learn.microsoft.com/ko-kr/windows/wsl/install
- https://code.visualstudio.com/docs/remote/wsl
- https://docs.ros.org/en/humble/Installation/Ubuntu-Install-Debs.html
- https://github.com/ros-infrastructure/ros-apt-source
- https://hub.docker.com/_/ros
- https://docs.docker.com/reference/compose-file/interpolation/
